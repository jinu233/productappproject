from django.contrib import admin
from feedbackproject.models import feedback
# Register your models here.
admin.site.register(feedback)