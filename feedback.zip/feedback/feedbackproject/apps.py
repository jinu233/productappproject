from django.apps import AppConfig


class FeedbackprojectConfig(AppConfig):
    name = 'feedbackproject'
